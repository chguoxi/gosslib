<?

class cbSQLRetrieveData {
	
	
}

class cbSQLConnectVar {
	
	const DB_DEFAULT = 0x000000;
	const DB_MYSQL   = 0x000001;
	const DB_POSTGRE = 0x000005;
	const DB_SQLITE  = 0x000010;
	
	const FETCH_ASSOC =  15;
	const FETCH_LAZY  =  25;
	const FETCH_OBJECT = 35;
	
	
	
}

?>