<?php
$users = array('belck','mazy','gate','marry');
$username = htmlentities($_GET['username']);
if (in_array($username, $users)){
	echo 'false';
}
else {
	echo 'true';
}
exit();