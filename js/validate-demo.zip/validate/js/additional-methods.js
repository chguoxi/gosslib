jQuery.validator.addMethod("userExist", function(value, element) {
	var check = false;
	var htmlObj = jQuery.ajax({
		url:"/demo/check_user.php?usname="+value,
		async:false,
		dataType:'String'
	});
	if( htmlObj.responseText==1 ){
		check = true;
	}
	return this.optional(element) || check;
}, "Please enter a correct date");